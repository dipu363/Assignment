class Task{

  late int id;
  late String  title;
  late String  description;
  late String  submission;
  late String  status;

  Task.ass(this.id,this.title, this.description, this.submission, this.status);
}